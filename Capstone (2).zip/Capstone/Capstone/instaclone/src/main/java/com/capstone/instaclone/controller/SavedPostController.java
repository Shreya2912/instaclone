package com.capstone.instaclone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.instaclone.dao.SavedPostsRepo;
import com.capstone.instaclone.model.SavedPost;
@CrossOrigin
@RestController
public class SavedPostController {
	
	@Autowired
	SavedPostsRepo Savepostrepo;
	
	
	@PostMapping("/savedpost")
	public SavedPost addsavepost(@RequestBody SavedPost savedpost) {
		return Savepostrepo.save(savedpost);
	}
	
	@GetMapping("/savedpost")
	public List<SavedPost> getsavedpost(){
		return (List<SavedPost>) Savepostrepo.findAll();
	}
	

}
