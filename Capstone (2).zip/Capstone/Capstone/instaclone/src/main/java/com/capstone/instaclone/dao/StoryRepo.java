package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Story;



public interface StoryRepo extends CrudRepository<Story, Integer>{

}
