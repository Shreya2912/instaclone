package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Posts;

public interface PostsRepo extends CrudRepository<Posts, Integer>{

}
