package com.capstone.instaclone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.capstone.instaclone.dao.FollowingRepo;
import com.capstone.instaclone.model.Following;

@CrossOrigin
@RestController
public class FollowingController {
	
	@Autowired
	FollowingRepo followingRepo;
	
	@PostMapping("/following")
	public Following addfollower(@RequestBody Following following) {
		return followingRepo.save(following);
	}

	
	@GetMapping("/following")
	public List<Following> getfollower(){
		return (List<Following>) followingRepo.findAll();
	}

}
