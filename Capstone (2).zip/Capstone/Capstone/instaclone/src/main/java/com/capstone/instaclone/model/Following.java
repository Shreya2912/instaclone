package com.capstone.instaclone.model;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Following {
	
	@Id
	@GeneratedValue
	private int following_id;
	private String own_userename;
	private String following_username;
	
	
	
	public String getOwn_userename() {
		return own_userename;
	}
	public void setOwn_userename(String own_userename) {
		this.own_userename = own_userename;
	}
	
	public String getFollowing_username() {
		return following_username;
	}
	public void setFollowing_username(String following_username) {
		this.following_username = following_username;
	}
	@Override
	public String toString() {
		return "Following [following_id=" + following_id + ", own_userename=" + own_userename + ", following_username="
				+ following_username + "]";
	}
	
	
}
