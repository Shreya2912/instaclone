package com.capstone.instaclone.dao;

 

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

 

import com.capstone.instaclone.model.User_details;

 

@Repository
public interface User_detailsRepo extends CrudRepository<User_details, String>{


//	User_details getOne(String user_name);
	


		

//	User_details findByUsername(String user_name);

//	List<User_details> findByuser_name(String user_name);
	
}