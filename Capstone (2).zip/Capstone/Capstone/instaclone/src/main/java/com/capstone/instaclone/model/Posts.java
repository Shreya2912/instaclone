package com.capstone.instaclone.model;

import java.security.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import jakarta.annotation.Nonnull;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity(name="Posts")
public class Posts {
	
	@Id
	@GeneratedValue
	private int postid;
//	private String img_path;
	@Column(columnDefinition="TEXT")
	private String postText;
//	private String caption;
	private String poster_username;
	private int no_of_likes;
	@Temporal(TemporalType.TIMESTAMP)
	private Date time_stamp;
	
	public int getPostid() {
		return postid;
	}
	
	public String getPostText() {
		return postText;
	}

	public void setPostText(String postText) {
		this.postText = postText;
	}

//	public String getImg_path() {
//		return img_path;
//	}
//	public void setImg_path(String img_path) {
//		this.img_path = img_path;
//	}
//	public String getCaption() {
//		return caption;
//	}
//	public void setCaption(String caption) {
//		this.caption = caption;
//	}
	
	public String getPoster_username() {
		return poster_username;
	}
	public void setPoster_username(String poster_username) {
		this.poster_username = poster_username;
	}
	
	public int getNo_of_likes() {
		return no_of_likes;
	}
	public void setNo_of_likes(int no_of_likes) {
		this.no_of_likes = no_of_likes;
	}
	public Date getTime_stamp() {
		return time_stamp;
	}
	public void setTime_stamp(Date time_stamp) {
		this.time_stamp = time_stamp;
	}

	@Override
	public String toString() {
		return "Posts [postid=" + postid + ", postText=" + postText + ",poster_username="
				+ poster_username + ", no_of_likes=" + no_of_likes + ", time_stamp=" + time_stamp + "]";
	}
	
	
	

}
