package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.SavedPost;

public interface SavedPostsRepo extends CrudRepository<SavedPost, Integer>{

}
