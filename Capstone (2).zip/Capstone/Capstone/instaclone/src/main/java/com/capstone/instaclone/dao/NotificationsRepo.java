package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Notifications;

public interface NotificationsRepo extends CrudRepository<Notifications, Integer>{

}
