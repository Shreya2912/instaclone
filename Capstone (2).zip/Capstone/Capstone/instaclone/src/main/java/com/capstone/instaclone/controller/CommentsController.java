package com.capstone.instaclone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.instaclone.dao.commentsRepo;
import com.capstone.instaclone.model.Comments;
@CrossOrigin
@RestController
public class CommentsController {
	
	@Autowired
	commentsRepo commentRepo;
	
	@PostMapping("/comments")
	public void addComment(@RequestBody Comments comments) {
		commentRepo.save(comments);
	}

	
	@GetMapping("/comments/{postId}")
	public List<Comments> getComments(@PathVariable int postId){
		return (List<Comments>)  commentRepo.findBypostId(postId);
	}
	
	@GetMapping("/comments")
	public List<Comments> getComment(){
		return (List<Comments>)  commentRepo.findAll();
	}
}
