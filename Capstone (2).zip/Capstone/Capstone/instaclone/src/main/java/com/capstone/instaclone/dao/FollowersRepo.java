package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Followers;

public interface FollowersRepo extends CrudRepository<Followers, Integer>{

}
