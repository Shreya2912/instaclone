package com.capstone.instaclone.model;

import jakarta.annotation.Nonnull;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity(name="SavedPost")
public class SavedPost {
	
	@Id
	@GeneratedValue
	private int savep_id;
	private String owner_username; 
	private int post_id ;
	

	
	public String getOwner_username() {
		return owner_username;
	}

	public void setOwner_username(String owner_username) {
		this.owner_username = owner_username;
	}

	public int getPost_id() {
		return post_id;
	}

	public void setPost_id(int post_id) {
		this.post_id = post_id;
	}

	@Override
	public String toString() {
		return "SavedPost [savep_id=" + savep_id + ", owner_username=" + owner_username + ", post_id=" + post_id + "]";
	}


	

	
	
	

	
	

}
