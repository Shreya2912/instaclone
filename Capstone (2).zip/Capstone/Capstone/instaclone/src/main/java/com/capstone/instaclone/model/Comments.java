package com.capstone.instaclone.model;

import java.security.Timestamp;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Comments {
	
	@Id
	@GeneratedValue
	private int comment_id;
	private String comment;
	private int postId;
	private String commenter_username;
	public String getComment() {
		return comment;                              
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getCommenter_username() {
		return commenter_username;
	}
	public void setCommenter_username(String commenter_username) {
		this.commenter_username = commenter_username;
	}
	@Override
	public String toString() {
		return "Comments [comment_id=" + comment_id + ", comment=" + comment + ", postId=" + postId
				+ ", commenter_username=" + commenter_username + "]";
	}
	
	
	
}
	
