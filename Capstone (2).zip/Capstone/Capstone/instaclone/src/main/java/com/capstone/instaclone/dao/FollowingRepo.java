package com.capstone.instaclone.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Following;

public interface FollowingRepo extends CrudRepository<Following, Integer> {

}
