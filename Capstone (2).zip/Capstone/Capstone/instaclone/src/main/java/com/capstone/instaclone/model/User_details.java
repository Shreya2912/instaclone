package com.capstone.instaclone.model;

 

import java.util.Arrays;
import java.util.Set;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;

 

@Entity(name="User_details")

 

public class User_details {

    
    @Id
    private String user_name;
    private String email;
    private String full_name;
    private String user_password;
    private String bio;
//    @Lob
//    @Column(name = "user_image", length = Integer.MAX_VALUE, nullable = true)
//    private byte[] user_image;
     
//    private int follower_count;
//    private int following_count;
//    private boolean account_type;
    private int no_of_posts;
    

    public String getUser_name() {
		return user_name;
	}
	
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

    public String getUser_password() {
        return user_password;
    }
    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }


    public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}

	
//	public byte[] getUser_image() {
//		return user_image;
//	}
//	public void setUser_image(byte[] user_image) {
//		this.user_image = user_image;
//	}
//	public int getFollower_count() {
//		return follower_count;
//	}
//	public void setFollower_count(int follower_count) {
//		this.follower_count = follower_count;
//	}
//	public int getFollowing_count() {
//		return following_count;
//	}
//	public void setFollowing_count(int following_count) {
//		this.following_count = following_count;
//	}
//	public boolean isAccount_type() {
//		return account_type;
//	}
//	public void setAccount_type(boolean account_type) {
//		this.account_type = account_type;
//	}
	public int getNo_of_posts() {
		return no_of_posts;
	}
	public void setNo_of_posts(int no_of_posts) {
		this.no_of_posts = no_of_posts;
	}
	@Override
	public String toString() {
		return "User_details [user_name=" + user_name + ", email=" + email + ", full_name="
				+ full_name + ", user_password=" + user_password + ", bio=" + bio + ",  no_of_posts=" + no_of_posts + "]";
	}
	

}