package com.capstone.instaclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstacloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstacloneApplication.class, args);
	}

}
