package com.capstone.instaclone.model;

import java.util.Arrays;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Story {
	
	@Id
	@GeneratedValue
	private int story_id;
	private String username;
	@Column(columnDefinition="TEXT")
	private String story_content;
	@Temporal(TemporalType.TIMESTAMP)
	private Date time_stamp;
	
//	public int getStory_id() {
//		return story_id;
//	}
//	public void setStory_id(int story_id) {
//		this.story_id = story_id;
//	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getStory_content() {
		return story_content;
	}
	public void setStory_content(String story_content) {
		this.story_content = story_content;
	}
	public Date getTime_stamp() {
		return time_stamp;
	}
	public void setTime_stamp(Date time_stamp) {
		this.time_stamp = time_stamp;
	}
	@Override
	public String toString() {
		return "Story [story_id=" + story_id + ", username=" + username + ", story_content=" + story_content
				+ ", time_stamp=" + time_stamp + "]";
	}
	
	
	
	

}
