package com.capstone.instaclone.controller;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.instaclone.dao.PostsRepo;
import com.capstone.instaclone.model.Posts;
@CrossOrigin
@RestController

public class PostController {
	
	@Autowired
	PostsRepo postrepo;
	
	@PostMapping("/posts")
	public Posts addPost(@RequestBody Posts post) {
		post.setTime_stamp(Calendar.getInstance().getTime());
		return postrepo.save(post);
		
	}
	
	@GetMapping("/posts")
	public List<Posts> getPosts(){
		return (List<Posts>) postrepo.findAll();
	}
	
//	@GetMapping("/posts")
//	public List<Posts> getPost(){
//		List<Posts> posts=(List<Posts>) postrepo.findAll();
//		List<Posts> updatedPosts=new LinkedList<>();
//		for(Posts post:posts)
//		{
//			String[] imagePathAsArray=post.getImg_path().split("\\\\");
//			post.setImg_path(new String("http://localhost:8080/").concat(imagePathAsArray[imagePathAsArray.length-1]));
//			updatedPosts.add(post);
//		}
//		return updatedPosts;
//	}
	
	@GetMapping("/posts/{postid}")
	public Posts getPost(@PathVariable int postid) {
		List<Posts> posts= (List<Posts>) postrepo.findAll();
		return posts.get(postid);
//		if(post.isPresent()) {
//		   return Optional.of(post.get());
//		}
//		else {
//		    throw new Exception();
//		}
//		return (Optional<Posts>) postrepo.getById(id);
	}
	
	@PutMapping("/updateLike/{postid}")
	public void updateLike(@RequestBody Posts post,@PathVariable int postid) {
		Posts updatepost=postrepo.findById(postid).orElse(null);
		
		updatepost.setNo_of_likes(post.getNo_of_likes());
		postrepo.save(updatepost);
	}
	
	
	
	

}
