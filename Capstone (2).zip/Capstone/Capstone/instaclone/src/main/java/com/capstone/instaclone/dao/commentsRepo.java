package com.capstone.instaclone.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capstone.instaclone.model.Comments;

public interface commentsRepo extends CrudRepository<Comments, Integer> {

//	List<Comments> findByPost_Id(int post_id);
    @Query("from Comments where postId=?1")
	List<Comments> findBypostId(int postId);

}
