package com.capstone.instaclone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.instaclone.dao.NotificationsRepo;
import com.capstone.instaclone.model.Notifications;
@CrossOrigin
@RestController
public class NotificationsController {
	
	@Autowired 
	NotificationsRepo notificationRepo;
	
	
	@PostMapping("/notifications")
	public Notifications addNotification(@RequestBody Notifications notifications) {
		return notificationRepo.save(notifications);
	}

	
	@GetMapping("/notifications")
	public List<Notifications> getNotification(){
		return (List<Notifications>) notificationRepo.findAll();
		
	}
}
