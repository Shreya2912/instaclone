package com.capstone.instaclone.model;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity(name="follower")
public class Followers {
	
	@Id
	@GeneratedValue
	private int follower_id;
	private String own_user_name;
	private String follower_username;
	public String getOwn_user_name() {
		return own_user_name;
	}
	public void setOwn_user_name(String own_user_name) {
		this.own_user_name = own_user_name;
	}
	public String getFollower_username() {
		return follower_username;
	}
	public void setFollower_username(String follower_username) {
		this.follower_username = follower_username;
	}
	@Override
	public String toString() {
		return "Followers [follower_id=" + follower_id + ", own_user_name=" + own_user_name + ", follower_username="
				+ follower_username + "]";
	}
	
	
	
	
}
