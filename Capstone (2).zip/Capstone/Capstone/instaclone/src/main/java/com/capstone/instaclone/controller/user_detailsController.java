package com.capstone.instaclone.controller;

 


import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capstone.instaclone.dao.User_detailsRepo;
import com.capstone.instaclone.model.Posts;
import com.capstone.instaclone.model.User_details;

 
@CrossOrigin
@RestController
//@RequestMapping("user_details")
public class user_detailsController {

    @Autowired
    User_detailsRepo user_detailrepo;

//    @PostMapping("/user_details/{user_name}")
//    public String uploadImage(@RequestParam("file") MultipartFile file) throws Exception{
//		String Path_Directory="C:\\Users\\Neha.Koyande\\Capstone\\instaclone\\src\\main\\resources\\static\\images";
//		Files.copy(file.getInputStream(),Paths.get(Path_Directory+File.separator+file.getOriginalFilename()),StandardCopyOption.REPLACE_EXISTING);
//    	return "hii";
//    }

    @PostMapping("/user_details")
    public User_details add_details(@RequestBody User_details user_detail){
         return user_detailrepo.save(user_detail);


    }
    
//    @GetMapping("/user_details/{user_name}")
//    public String uploadImage(@RequestParam("file") MultipartFile file) throws Exception{
//		String Path_Directory="C:\\Users\\Neha.Koyande\\Capstone\\instaclone\\src\\main\\resources\\static\\images";
//		Files.copy(file.getInputStream(),Paths.get(Path_Directory+File.separator+file.getOriginalFilename()),StandardCopyOption.REPLACE_EXISTING);
//    	return "hii";
//    	
//    }
//    @GetMapping("/user_details/{user_name}")
//    public  Optional<User_details> getUser(String user_name){
//    	return user_detailrepo.findById(user_name);
    
    
//    @GetMapping("/user_details/{user_name}")
//    public String getUser(@PathVariable String user_name){
//    	User_details user=user_detailrepo.findById(user_name).orElse(null);
//    	
//    	return user.getUser_image();
//    }
//    
    @GetMapping("/user_details")
    public List<User_details> getUser(){
    	return (List<User_details>) user_detailrepo.findAll();
//    	
//    	
    }
    
    @GetMapping("/user_details/{username}")
    public User_details getSpecificUser(@PathVariable String username){
    	
    	return user_detailrepo.findById(username).orElse(null);
//    	
//    	
    }
    
    
//    @DeleteMapping("/user_details/{user_name}")
//    public void deleteUser(@PathVariable String user_name) {
//    	User_details ud = user_detailrepo.getOne(user_name);
//    	user_detailrepo.delete(ud);
//    }
    
    
//    
//    @PutMapping("/user_details/{user_name}")
//    public User_details putEmployee(@RequestBody User_details user_detail,@PathVariable String user_name) {
//    	User_details updateuser_details =user_detailrepo.findById(user_name).orElse(null);
//    	
//    	updateuser_details.setFull_name(user_details.getFull_name());
//    	
//    	return user_detailrepo.save(user_detail);
//		
//	}
    
    @PutMapping("/user_details/{user_name}")
    public void putEmployee(@RequestBody User_details user_detail,@PathVariable String user_name) {
    	User_details updateuser_details =user_detailrepo.findById(user_name).orElse(null);
    	
    	updateuser_details.setFull_name(user_detail.getFull_name());
//    	updateuser_details.setEmail(user_detail.getEmail());
//    	updateuser_details.setBio(user_detail.getBio());
    	user_detailrepo.save(updateuser_details);
//    	return user_detailrepo.save(user_detail);
		
	}

 

}