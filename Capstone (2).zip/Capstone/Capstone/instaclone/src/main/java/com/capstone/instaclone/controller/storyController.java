package com.capstone.instaclone.controller;

import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.instaclone.dao.StoryRepo;
import com.capstone.instaclone.model.Story;

@CrossOrigin
@RestController
public class storyController {
	
	@Autowired
	StoryRepo storyRepo;
	
	
	@PostMapping("/story")
	public Story addStory(@RequestBody Story story) {
		story.setTime_stamp(Calendar.getInstance().getTime());
		return storyRepo.save(story);
	}

	
	@GetMapping("/story")
	public List<Story>  getStory(){
		return (List<Story>) storyRepo.findAll();
	}
}
