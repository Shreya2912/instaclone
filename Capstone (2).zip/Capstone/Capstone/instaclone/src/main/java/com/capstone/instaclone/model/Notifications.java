package com.capstone.instaclone.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Notifications {
	
	@Id
	@GeneratedValue
	private int notifi_id;
	private String notification;
	private String my_user_name;
	public String getNotification() {
		return notification;
	}
	public void setNotification(String notification) {
		this.notification = notification;
	}
	public String getMy_user_name() {
		return my_user_name;
	}
	public void setMy_user_name(String my_user_name) {
		this.my_user_name = my_user_name;
	}
	@Override
	public String toString() {
		return "Notifications [notifi_id=" + notifi_id + ", notification=" + notification + ", my_user_name="
				+ my_user_name + "]";
	}
	
	

}
