package com.capstone.instaclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstacloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
