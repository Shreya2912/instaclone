import React from 'react'

function Saved() {
  return (
    <div className="main_div">
        {/* {Saved.map((save) =>{save.})} */}
      
    </div>
  )
}

export default Saved
