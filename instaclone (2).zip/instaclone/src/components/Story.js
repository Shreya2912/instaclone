import React from 'react'

function Story(props) {

    const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
    
  return (
    <div>
      {/* <Avatar onClick={handleOpen} className="story_img"  ></Avatar>
      {/* <div class="name">{props.status.username}</div> */}

      {/* <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description">
                <Box sx={style}>
                  <Typography id="modal-modal-title" variant="h6" component="h2">
                    <h4>{props.status}</h4>
                    
                  </Typography>

                </Box>
              </Modal>  */}
            <h1>{props.status}</h1>
    </div>
  )
}

export default Story

