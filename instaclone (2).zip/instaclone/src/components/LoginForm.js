import React, { useState, useEffect } from 'react'
import "./login.css";
import { useNavigate } from 'react-router-dom'
import axios from 'axios';
import { Link } from 'react-router-dom'
import blogging from './blogging.jfif'

function LoginForm() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

 

  const Navigate = useNavigate()


  const handleUsername = (e) => {
    setUsername(e.target.value);
    
  };
  const handlePassword = (e) => {
    setPassword(e.target.value);
    
  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    console.log(username)
    await (axios.get(`http://localhost:8082/user_details/${username}`)

      .then(res => {

        if (username === (res.data.user_name) && password === (res.data.user_password)) {


          localStorage.setItem('user', username);
          Navigate('/FeedPage')



        } else {
          return (
            alert("Acess Denied")
          )
        }

      })

      .catch(err => {

        console.log(err)

      })
    
    )}





  return (
    
    <div className="sign1">

      <div className='loginpage__main1'>
        <img style={{'width':'75%',marginLeft:'25px'}}src={blogging} width="650px" />
      </div>

      <div className="Form1">

        <h1 style={{ 'height': '40px', 'width': '100%' }}>𝕭𝖑𝖔𝖌𝖌 𝕴𝖙</h1><br></br>

        <form  >

          <div className="InputArea"><br></br><br></br>
            <input placeholder='UserName' style={{ 'borderRadius': '5px', 'width': '40%' }} onChange={handleUsername} className="input"
              value={username} type="text" /><br></br><br></br>
            <input placeholder='Password' style={{ 'borderRadius': '5px', 'width': '40%' }} onChange={handlePassword} className="input"
              value={password} type="password" /><br></br><br></br><br></br>
            <button className="submitButton" onClick={handleSubmit}>Submit</button><br></br>

            <p>Don't have an account?  <Link to="/Signup">Sign up</Link></p>
          </div>



          <div>

          </div>

        </form>

      </div>
    </div>
  )
}

export default LoginForm
