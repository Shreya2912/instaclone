import React, { useState } from 'react'
import './addpost.css'
import addPost from './addPost.png'
import blogging from './blogging.png'
import axios from 'axios';
import { useNavigate } from 'react-router';
import NavBar from './NavBar';
import TextareaAutosize from '@mui/base/TextareaAutosize';


function AddPost() {

 

  
  
  const [blog,setBlog] =useState([])
  const [story,setStory] =useState([])
  const navigate = useNavigate();



  const handleSubmit = (e) =>{
    axios.post(

      "http://localhost:8082/posts",
      { postText: blog,
        poster_username:localStorage.getItem("user"),
         },[]);
    console.log("end of post call")
    navigate("/FeedPage")
    console.log("navigated to feed page")
  };

  const handleSub = (e) =>{
    axios.post(

      "http://localhost:8082/story",
      { story_content: story,
        username:localStorage.getItem("user"),
         },[]);
    console.log("end of post call")
    navigate("/FeedPage")
    console.log("navigated to feed page")
    window.location.reload();
  };

  


  return (
    <div>
      {/* <h1>{username}</h1> */}
      <NavBar/>
      <div className="maindiv">
        <div>
          <h3>Write Your Blog</h3>
          <img className="icon" src={blogging}></img><br></br>
          
          
          <TextareaAutosize  style={{width:"85%"}}tabIndex={6} maxRows={4} value={blog} onChange={(e) =>setBlog(e.target.value)}/><br></br>
          <button type="button" class="btn btn-secondary" onClick={handleSubmit}>Add</button><br></br><br></br>

          <h3>Post a Story</h3>
          <TextareaAutosize  style={{width:"85%"}}tabIndex={6} maxRows={2} value={story} onChange={(e) =>setStory(e.target.value)}/><br></br>
          <button type="button" class="btn btn-secondary" onClick={handleSub}>Add</button><br></br><br></br>
          
        </div>

      </div>
    </div>

  )
}

export default AddPost
