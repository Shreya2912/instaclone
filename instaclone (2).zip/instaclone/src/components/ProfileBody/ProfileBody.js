
import { ImageList } from '@mui/material'
import axios from 'axios'
import React, { useState, useEffect } from 'react'
import './profileBody.css'


export default function ProfileBody() {
    const [posts, setPosts] = useState([])
    const[id,setId]=useState("")
    const x = localStorage.getItem("user")

    useEffect(() => {
        axios.get(`http://localhost:8082/post/${x}`)
            .then(res => {

                setPosts(res.data)

            })
            .catch(err => {

                console.log(err)

            })

    }, [])


    return (
        <div className='bodyNav'>
            <ImageList sx={{ width: 950 }} cols={3} rowHeight={164}>
                {posts.map(post =>
                <div>
                     
                    <table>
                        <tr className='tableRow'>
                            <td className='tableBox' style={{ backgroundColor: 'FFC3A1' }}>
                                {
                                    <div className="item">
                                        <div><h4>{post.postText}</h4></div>
                                        <div><button onClick={async (e)=>{
                                         await axios.delete(`http://localhost:8082/delete/${post.postid}`);
                                        window.location.reload()}} className="delete-button">Delete</button></div>
                                        
                                    </div>
                                }
                            </td>
                        </tr>
                    </table>
                </div>)}
            </ImageList>
        </div>
    )
}