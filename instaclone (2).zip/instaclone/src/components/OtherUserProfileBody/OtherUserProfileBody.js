import React, {useState,useEffect} from 'react'
import {Link} from 'react-router-dom'

import './otherUserProfileBody.css'


export default function OtherUserprofileBody() {
   





    return (
        <div className='bodyNav'>
            

               
                <table>
                    <tr className='tableRow'>
                    <td className='tableBox'>post5</td>
                    <td className='tableBox'>post4</td>
                        <td className='tableBox'>post1</td>
                        <td className='tableBox'>post2</td>
                        <td className='tableBox'>post3</td>
                    </tr>
                </table>
               

            </div>


            


            


      


        
    )
    }
