import React, { useState, useEffect } from 'react'
import axios from 'axios';
import './profileStatus.css'
import { Link } from 'react-router-dom'
import { Avatar } from '@mui/material'



export default function ProfileStatus() {

    const [username, setUsername] = useState('');
    const [post, setPost] = useState([])
    const [bio, setBio] = useState('');

    const y = localStorage.getItem("user")

    useEffect(() => {

        axios.get(`http://localhost:8082/user_details/${y}`)

            .then(res => {
                
                setUsername(res.data)

            })


            .catch(err => {
                console.log(err)
            })
    }, [])

    useEffect(() => {

        axios.get(`http://localhost:8082/post/${y}`)

            .then(res => {
                setPost(res.data)

            })


            .catch(err => {
                console.log(err)
            })
    }, [])




    return (



        <div className='statusDiv'>
            <div>

                <div className='statusUl'>


                    <div className='statusLi'>

                        <Avatar style={{ height: '150px', width: '150px', margin: '10px 20px' }}></Avatar>
                        <div className='username'>{localStorage.getItem("user")}</div>


                        <div><button className="settings" type="button" data-bs-toggle="modal" data-bs-target="#model3"> </button></div>

                        <div className="modal" id="model3">
                            <div className="modal-dialog">
                                <div className="modal-content">
                                    <div className="modal-header">
                                        <h5 className="modal-title">Settings</h5>
                                        <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                                    </div>


                                    <div>
                                        <Link to="/EditP">
                                            <button className='settingsPopUp' data-bs-dismiss="modal">Edit Profile</button><br></br>
                                        </Link>
                                        <Link to="/LoginForm">
                                            <button className='settingsPopUp' data-bs-dismiss="modal">LogOut</button><br></br>
                                        </Link>

                                    </div>


                                    <div className="modal-footer">
                                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    </div>

                                </div>

                            </div>

                        </div>

 
                        <div className='statusLi2'>
                            <br></br>
    

                        </div>
                    </div>
                    

                    <div className='statusLi4'>

                        {post.length} Posts

                    </div>






                </div>
            </div>
            <br></br>
            <br></br>
            <div style={{float:'left', fontSize:'30px', paddingLeft:'10px'}}>
            {username.full_name}
            </div>
            <br></br>
            <br></br>
            <div className='statusBio'>
                {
                    username.bio
                }
            </div>





        </div>


    )
}

