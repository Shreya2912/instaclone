import { Avatar } from '@mui/material'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import './StatusBar.css'


function Status() {

  const [story, setStory] = useState([])
  const [modalStory, setModalStory] = useState()
  const [user,setUser]=useState("")
  const y= localStorage.getItem("user")


  useEffect(() => {
    axios.get(`http://localhost:8082/story`)

      .then(res => {
        setStory(res.data);
      })

      .catch(err => {
        console.log(err)
      })

  }, [])


  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    // border: '0px solid black',
    boxShadow: 24,
    p: 4,
  };

  const storyDelete=()=>{
    axios.delete(`http://localhost:8082/storys/${y}`)

    window.location.reload()
  }

  
  return (
    <div>
      <div className="Statusdiv">

        {story.map(Story =>
          <div>
            <div key={Story.story_id} class="story">

              <Avatar onClick={(e)=>{setModalStory(Story.story_content);setUser(Story.username)}} className="story_img" alt={Story.username} src={Story.username} data-bs-toggle="modal" data-bs-target="#exampleModal"></Avatar>
              <div class="name">{Story.username}</div>        
                
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5" id="exampleModalLabel">{user}</h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    <h4>{modalStory}</h4>
                    {(localStorage.getItem("user")===user)&&<button type="button" className="story-delete" data-bs-dismiss="modal" onClick={storyDelete} >Delete</button>}
                    </div>
              
                  </div>
                </div>
              </div>
              
            </div >

          </div>
        )}
      </div>
    </div>
  )
}

export default Status