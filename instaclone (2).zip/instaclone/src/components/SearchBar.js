import { Autocomplete, Avatar, TextField } from '@mui/material'
import axios from 'axios'
import React, { useEffect, useState,useNavigate } from 'react'


function SearchBar() {

    const [user, setUser] = useState([])
    const[data,setData]=useState('')

    

    // const navigate=useNavigate()
    const search = e => {
        e.preventDefault();
        // navigate("/OtherUserProfileFeed/" + e.target.search.value);
      };

    useEffect(() => {

        axios.get

            (`http://localhost:8082/user_details`)

            .then(res => {

                setUser(res.data);

            })

            .catch(err => {

                console.log(err)

            })

    }, [])
    return (
        <div>
            <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={user.map(user =>user.user_name)}
                    // <div>
                    //     <Avatar src={user.map(user =>user.user_image)}></Avatar>
                    // <h4>{user.map(user =>user.user_name)}</h4>
                    // </div>}
                sx={{ width: 300 }}
                renderInput={(params) => <TextField {...params} label="Search" />}
                inputValue={data}
                onInputChange={(e)=>setData(e.target.value)}
                onClick={search}
            />
            {console.log(data)}

            

        </div>
    )
}

export default SearchBar
