import { Avatar } from '@mui/material'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import './post.css'
import Comment from '../Comment'


function Post() {

  const [posts, setPosts] = useState([])
  const [com, setComment] = useState([])
  const path = localStorage.getItem("id")


  useEffect(() => {
    axios.get(`http://localhost:8082/posts`)

      .then(res => {
        setPosts(res.data);
      })

      .catch(err => {
        console.log(err)
      })

  }, [])


  const handleComment = () => {

    axios.post(`http://localhost:8082/comments`,
      {
        comment: com,
        commenter_username: localStorage.getItem("user"),
        postId: localStorage.getItem("id")
      })

    window.location.reload();
  }


  return (
    <div >
      {posts.map(post => (
        <div className="postdiv" key={post.postid}>

          <div className="header">
            <Avatar alt={post.poster_username} src={post.poster_username} className="header_img" ></Avatar>
            <div className="post_username">{post.poster_username}</div>
            
            
          </div>

          
<div className="time">
          {post.time_stamp.substring(4,7)}&nbsp;
          {post.time_stamp.slice(24,28)}&nbsp;
            {post.time_stamp.substring(11, 16)}
          </div><br></br>



          <div className="post_img">
            <h4>{post.postText}</h4>
          </div>

          <div className="comment">
            {/* displaying comments */}
            <Comment postId={post.postid} /> 

            <input className="commentValue" type="text" value={com[posts.postid]} onChange={(e) => {
              //to send the postid while adding the comment to db
              { localStorage.setItem('id', post.postid) }
              setComment(e.target.value)
            }}></input>
            <button className="commentButton" type="submit" onClick={handleComment}>Add Comment</button>
          </div>

        </div>
      ))}

    </div>
  )
}

export default Post
