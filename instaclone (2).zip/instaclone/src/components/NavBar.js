import React, { useState } from 'react'
import styles from './Navbar.module.css'
import home from './home.png'
import search from './search.png'
import notification from './notification.png'
import messages from './messages.png'
import create from './create.png'
import profile from './profile.png'
import { Box, Modal } from '@mui/material'
import SearchBar from './SearchBar'
import { Link } from 'react-router-dom'
import { useParams } from "react-router-dom";


function NavBar() {

    // const {userName} = useParams();

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 600,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
      };
    
      const [open, setOpen] = React.useState(false);
      const handleOpen = () => setOpen(true);
      const handleClose = () => setOpen(false);
      const iconStyle = {
    
        width: "25px",
        height: "25px"
    
      }
    
    return (
            <div className={styles.sec_maindiv}>

                <h2 style={{ textAlign: "left", marginLeft: "40px", marginBottom: "15px", marginTop: "35px", fontFamily: "Grandista" }}>𝕭𝖑𝖔𝖌𝖌 𝕴𝖙</h2>

                <div className="navlist">

                    <Link to="/FeedPage"><button className={styles.navbutton}><img className={styles.icon} src={home} />Home</button></Link><br/>

                    {/* <button onClick={handleOpen} className={styles.navbutton}><img className={styles.icon} src={search} />Search</button><br />
                    <Modal
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="parent-modal-title"
                        aria-describedby="parent-modal-description"
                    >
                        <Box sx={{ ...style, width: 400 }}>
                            <h2 id="parent-modal-title">Search</h2>
                            
                            <SearchBar />

                        </Box>
                    </Modal> */}

                    {/* <button className={styles.navbutton}><img className={styles.icon} src={notification} />Notifications</button><br />

                    <button className={styles.navbutton}><img className={styles.icon} src={messages} />Messages</button><br /> */}

                    <Link to="/AddPost"><button className={styles.navbutton}><img className={styles.icon} src={create} />Create</button></Link><br />

                    <Link to="/ProfileFeed"><button className={styles.navbutton}><img className={styles.icon} src={profile} />Profile</button></Link><br />

                </div>

            </div>
  )
}

export default NavBar
