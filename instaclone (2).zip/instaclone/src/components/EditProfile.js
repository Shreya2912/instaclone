import './Editprofile.css';
import rajmom from './raj_mamodia.jfif';
import React, { useEffect, useState } from 'react'
import home from './home.png'
import create from './create.png'
import search from './search.png'
import notification from './notification.png'
import messages from './messages.png'
import profile from './profile.png'
import axios from 'axios';
import { useNavigate } from 'react-router';
import NavBar from './NavBar';

function EditProfile() {

    const [full_name, setFull_name]=useState()
    const [user_name, setUser_name]=useState()
    const [bio, setBio]=useState()

    // const navigate=useNavigate()
    useEffect(()=>{

        axios.get(
            `http://localhost:8082/user_details`)
            .then(res=>{
                setUser_name(res.data);
            })
            .catch(err=>{
                console.log(err)
            })
        },[])   

    
    const handleSubmit = (e) => {

        axios.put(
            "localhost:8082/Insta/user_details/{}",
            {
                full_name,
                user_name,
                bio 
            }
        ) 
    }

    const rajstyle = {
        height : 38,
        width : 38,
        borderRadius : 19
    };

    return (
    <div>
        <NavBar/>
        {/* <div className="sec_maindiv_edit">
            <h2 style={{textAlign:"left",marginLeft:"40px",marginBottom:"15px",marginTop:"35px",fontFamily:"Grandista"}}>Instagram</h2>
            <div className="navlist">
                <button className="navbutton"><img className="icon" src={home}/>Home</button><br/>
                <button className="navbutton"><img className="icon" src={search}/>Search</button><br/>
                <button className="navbutton"><img className="icon" src={notification}/>Notifications</button><br/>
                <button className="navbutton"><img className="icon" src={messages}/>Messages</button><br/>
                <button className="navbutton"><img className="icon" src={create}/>Create</button><br/>
                <button className="navbutton"><img className="icon" src={profile}/>Profile</button><br/>
            </div>
        </div>
        <div class = "container">
            <div class = "Profile_Options">
                <ul class = "_ab85" >
                    <li>&emsp;&emsp;Edit Profile</li>
                    <li>&emsp;&emsp;Change password</li>
                    <li>&emsp;&emsp;Privacy and Security</li>
                </ul>
            </div>
            <div class = "Change_Password_Process">
                <div class = "formNames"><br/><br/>
                    <img class = "userImg" src={rajmom} style={rajstyle} alt="Raj Mamodia"/><br/><br/><br/>
                    <div class = "changepasswordtext">Name <br/>
                        Username <br/>
                        Bio </div> <br/>
                    </div>
                    <div class = "formFields">
                        <form onSubmit={handleSubmit}>
                            <br/><br/><b class = "usernameStyles">pairotechnic</b> <br/><br/><br/>
                            <input class = "passwordbox" type = "text" placeholder = "Full Name" onChange = {e => {setFull_name(e.target.value)}}></input><br/><br/>
                            <input class = "passwordbox" type = "text" placeholder = "Username" onChange = {e => {setUser_name(e.target.value)}}></input><br/><br/>
                            <input class = "passwordbox" type = "text" placeholder = "Bio" onChange = {e => {setBio(e.target.value)}}></input><br/><br/>
                            <input type="submit"></input>
                        </form>
                    </div>  
                </div>
            </div> */}
        </div>
    )
}

export default EditProfile
