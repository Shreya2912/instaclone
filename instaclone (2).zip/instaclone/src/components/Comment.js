import React, { useEffect, useState } from 'react'
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import './comment.css';
import del from './del.png';


function Comment(props) {   //props passed from  post.js

  const id = props.postId;
  const [comments, setComment] = useState([])
  // const [user,setUser]=useState("")
  const y = localStorage.getItem("user")

  useEffect(() => {
    axios.get(`http://localhost:8082/comments/${id}`)

      .then(res => {
        setComment(res.data);
      })

      .catch(err => {
        console.log(err)
      })

  }, []
  )

  const handleDel = (e) => {
    axios.delete(`http://localhost:8082/del/${y}/${id}`)
    e.preventDefault()
    window.location.reload()
  }


  return (
    <List sx={{ width: '100%', maxWidth: 360 }}>
      {comments.map(comment =>
        <div>
          <ListItem className="style" alignItems="flex-start">
            <ListItemAvatar>
              <Avatar alt={comment.commenter_username.toUpperCase()} src="/static/images/avatar/1.jpg" />
            </ListItemAvatar>

            <ListItemText
              primary={comment.commenter_username.toUpperCase()}
              secondary={
                <React.Fragment>
                  <Typography
                    sx={{ display: 'inline' }}
                    component="span"
                    variant="body2"
                  // color="text.primary"
                  >
                    {comment.comment}
                    {(localStorage.getItem("user") === comment.commenter_username) && <img onClick={handleDel} className="del" src={del} alt=""></img>}

                  </Typography>

                </React.Fragment>
              }
            />
          </ListItem>
        </div>
      )
      }
    </List>
  );
}

export default Comment