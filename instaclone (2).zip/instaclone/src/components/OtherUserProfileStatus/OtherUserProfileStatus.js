import React, { useState, useEffect } from 'react'
import './otherUserprofileStatus.css'
// import './EditProfile'
// import followers from './ProfileStatus/followers'


export default function profileStatus() {
    const initialCount = 0
    // const[followers,setFollowers] = useState([])

    
    // const handleFollow=(e)=>{

    //         axios.post('localhost:8082/followers',
    //         {
                
    //             user_name: {user_name}
                
    //         })
        
    //     }






    return (
        <div>
            <div className='statusDiv'>

                <div>
                    <ul className='statusUl'>


                        <li className='statusLi'>
                            <button className=' profilePic' style={{ display: 'flex', justifyContent: 'left' }}>

                            </button>

                        </li>


                        <li className='statusLi'>
                            <ul className='statusLi2'>
                                <li className='username'>username</li>

                                {/* <Link to="/EditProfile"> */}
                                <li>
                                    <button className='editProfile' >Follow</button>

                                </li>
                                {/* </Link> */}
                                <li>
                                    {/* <button className='settings' ></button> */}
                                    {/* <li><button className="settings" type="button" data-bs-toggle="modal" data-bs-target="#model3"> </button></li>
                                    <div>
                                        <div className="modal" id="model3">
                                            <div className="modal-dialog">
                                                <div className="modal-content">
                                                    <div className="modal-header">
                                                        <h5 className="modal-title">Settings</h5>
                                                        <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>


                                                    <div>
                                                        <button className='settingsPopUp'>Change Password</button><br></br>
                                                        <button className='settingsPopUp'>Privacy and Security</button><br></br>
                                                        <button className='settingsPopUp'>LogOut</button><br></br>
                                                        <button>Cancel</button>

                                                    </div>


                                                    <div className="modal-footer">
                                                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                                    </div>

                                                </div>

                                            </div>

                                        </div>
                                    </div> */}

                                </li>
                            </ul>
                        </li>
                        <br></br>
                        <br></br>
                        <br></br>
                        <br></br>

                        <li className='statusLi'>
                            <ul className='statusLi4'>
                                <li >Posts</li>
                                {/* <li><button className='followers' >Followers</button></li> */}
                                <li><button className="modelButton" type="button" data-bs-toggle="modal" data-bs-target="#model">
                                    Followers
                                </button></li>
                                <div>
                                    <div className="modal" id="model">
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title">Your Followers</h5>
                                                    <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                                                </div>


                                                <div>
                                                    <h6>
                                                        name1
                                                        name2
                                                    </h6>

                                                </div>


                                                <div className="modal-footer">
                                                    <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>


                                {/* <li><button className='following'>Following</button></li> */}
                                <li><button className="modelButton" type="button" data-bs-toggle="modal" data-bs-target="#model2">
                                    Following
                                </button></li>
                                <div>
                                    <div className="modal" id="model2">
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title">Your Following</h5>
                                                    <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                                                </div>


                                                <div>
                                                    <h6>
                                                        name1
                                                        name2
                                                    </h6>

                                                </div>


                                                <div className="modal-footer">
                                                    <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>

                            </ul>

                        </li>

                    </ul>
                </div>
                <li className='statusBio'>
                            Hello World! Learn React and Spring
                        </li>





            </div>

        </div>
    )
}

