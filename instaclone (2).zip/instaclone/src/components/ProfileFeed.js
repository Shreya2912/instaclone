import React from 'react'
import { Link } from "react-router-dom";
import './ProfileFeed.css'
import home from './home.png'
import search from './search.png'
import notification from './notification.png'
import messages from './messages.png'
import create from './create.png'
import profile from './profile.png'
import { Box, Modal } from '@mui/material'
import SearchBar from './SearchBar'
import NavBar from './NavBar';

import ProfileStatus from './ProfileStatus/ProfileStatus'
import ProfileBody from './ProfileBody/ProfileBody'




function ProfileFeed() {


    
    return (
        <div>
            

            <NavBar/>

            <ProfileStatus />



            <ProfileBody />



        </div>
    )
}

export default ProfileFeed
