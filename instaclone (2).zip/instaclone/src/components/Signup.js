import axios from 'axios';
import React from 'react'
import { useState,useEffect} from 'react';
import {useNavigate,Link} from 'react-router-dom'
import './signUp.css'
import blogging from './blogging.jfif'
function Signup() {
	
	const navigate=useNavigate();

	

    

    // States for registration
const [email, setEmail] = useState('');
const [full_name, setfullname] = useState('');
const [user_name, setUsername] = useState('');
const [user_password, setPassword] = useState('');
//const [retypepassword, setPassword1] = useState('');
// States for checking the errors
const [submitted, setSubmitted] = useState(false);
const [error, setError] = useState(false);

// Handling the name change
const handlefullname = (e) => {
	setfullname(e.target.value);
	setSubmitted(false);
};

const handleUsername = (e) => {
	setUsername(e.target.value);
	setSubmitted(false);
};

// Handling the email change
const handleEmail = (e) => {
	setEmail(e.target.value);
	setSubmitted(false);
};

// Handling the password change
const handlePassword = (e) => {
	setPassword(e.target.value);
	setSubmitted(false);
};



// Handling the form submission
const handleSubmit = (e) => {
	e.preventDefault();
	if (full_name === '' || email === '' || user_password === '') {
	setError(true);
	} else {
	setSubmitted(true);
	setError(false);

    axios.post(
        "http://localhost:8082/user_details",
        {
            email,
            full_name,
            user_name,
            user_password
        

        }

        
    )
		
		 navigate("/")

	}
};

// Showing success message
const successMessage = () => {
	return (
	<div
		className="success"
		style={{
		display: submitted ? '' : 'none',
		}}>
		<h1> Welcome,{full_name } successfully registered!!</h1>
	</div>
	);
};

// Showing error message if error is true
const errorMessage = () => {
	return (
	<div
		className="error"
		style={{
		display: error ? '' : 'none',
		}}>
		<h1>Please enter all the fields</h1>
	</div>
	);
};

  return (
    <div className='sign'>
		<div className="loginpage__main">
		<div>
         <img style={{'width':'75%',marginLeft:'85px',marginTop:"100px",borderRadius:"10px"}}src={blogging} width="450px" />
          </div>

		</div>
	

	
	<div className="Form">
	<div>
		<h1>𝕭𝖑𝖔𝖌𝖌 𝕴𝖙</h1>
		<br></br>
	</div>

	{/* Calling to the methods */}
	<div className="messages">
		{errorMessage()}
		{successMessage()}
	</div>
	

	<form>
	<input placeholder='Email' style={{'borderRadius':'5px'}} onChange={handleEmail} className="input"
        value={email} type="email" /><br></br><br></br>
	<input placeholder="FullName" style={{'borderRadius':'5px'}} onChange={handlefullname} className="input"
        value={full_name} type="text" /> <br></br><br></br>
		<input placeholder='UserName' style={{'borderRadius':'5px'}} onChange={handleUsername} className="input"
        value={user_name} type="text" /> <br></br><br></br>
		<input placeholder='Password' style={{'borderRadius':'5px'}} onChange={handlePassword} className="input"
        value={user_password} type="password" /><br></br><br></br>
		


		<button onClick={handleSubmit} className="btn" type="submit">
		Submit 
		
		
		</button></form><br></br>
		
		<div> <p >Have an account? <Link to="/"> <span>Log in</span></Link></p><br></br><br></br></div>
	</div>
	
	
	</div>
  )
}

export default Signup
