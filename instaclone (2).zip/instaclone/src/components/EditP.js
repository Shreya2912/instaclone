import React, { useEffect, useState,useLocation } from 'react'

import rajmom from './raj_mamodia.jfif';

import NavBar from './NavBar'

import './Editprofile.css';

import axios from 'axios';

import { Avatar } from '@mui/material';



function EditP() {



  const[detail,setDetail]=useState([])

  const [full_name, setFull_name]=useState("")

  const [email, setEmail]=useState("")

  const [bio, setBio]=useState("");

  

  

  let name=localStorage.getItem('user')



  const handleSubmit = (e) => {



    axios.put(

        `http://localhost:8082/user/${name}`,

        {

            full_name,

            email,

            bio

            

        }

    ) 

    e.preventDefault()

}



const rajstyle = {

  height : 38,

  width : 38,

  borderRadius : 19

};

  return (

    <div>

      <NavBar />

      <div className="container">

   

        <div className="Change_Password_Process">

          <div className="formNames"><br /><br />

            <Avatar className="userImg" alt={detail.user_name} src={detail.user_name} style={rajstyle}></Avatar><br /><br /><br />

            <div className="changepasswordtext">Name <br />

                        Email <br />

                        Bio </div> <br />

          </div>

          <div className="formFields">

            <form onSubmit={handleSubmit}>

              <br /><br /><b className="usernameStyles">{name}</b> <br /><br /><br />

              <input className="passwordbox" type="text" placeholder="Full Name" value={full_name}  onChange={e => { setFull_name(e.target.value) }}></input><br /><br />

              <input className="passwordbox" type="email" placeholder="Email" value={email} onChange={e => { setEmail(e.target.value) }}></input><br /><br />

              <input className="passwordbox" type="text" placeholder="Bio" value={bio} onChange={e => { setBio(e.target.value) }}></input><br /><br />

              <input style={{marginBottom:"13px"}}type="submit"></input>

              

              

            </form>

            

          </div>

        </div>

      </div> 

    </div>

  )

}



export default EditP