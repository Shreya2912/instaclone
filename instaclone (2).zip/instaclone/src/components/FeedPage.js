import React from 'react'
// import styles from './Feedpage.module.css'
import Post from './Posts/Post'
import Status from './Status Bar/Status'
import home from './home.png'
import search from './search.png'
import notification from './notification.png'
import messages from './messages.png'
import create from './create.png'
import profile from './profile.png'
import { Link, useLocation } from 'react-router-dom'
import SearchBar from './SearchBar'
import { Box, Modal } from '@mui/material'
import NavBar from './NavBar'

function FeedPage() {



  return (
    <div>
      
      <NavBar />
      <Status/>
      <Post/>


    </div>
  )
}

export default FeedPage
