import axios from 'axios';
import React, { useEffect, useState } from 'react'

function Testing() {

    const id=52;
    const [posts,setPost]=useState([])

    useEffect(() => {

        axios.get
      
          (`http://localhost:8082/comments/${id}`)
      
          .then(res => {
      
            setPost(res.data);
      
          })
      
          .catch(err => {
      
            console.log(err)
      
          })
      
      }, []
      )
  return (

    <div>
    <table>

    
      {posts.map(post=>
        (
        <tr key={post.comment_id}>
        <td>{post.comment}</td>
        </tr>
      ))}
    
    </table>
    </div>
  )
}

export default Testing
