import logo from './logo.svg';
import './App.css';
import FeedPage from './components/FeedPage'
import { BrowserRouter as Router, Routes, Route, Link, BrowserRouter } from "react-router-dom"
import AddPost from './components/AddPost';
import Signup from './components/Signup';
import LoginForm from './components/LoginForm'
import SearchBar from './components/SearchBar';
import EditProfile from './components/EditProfile';
import EditP from './components/EditP';
import Testing from './components/Testing';
import ProfileFeed from './components/ProfileFeed';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        
        <Route path="/" element={<LoginForm/>}/>
        <Route path="/Signup" element={<Signup/>}/>
        <Route path="/FeedPage" element={<FeedPage/>}/>
        <Route path="/AddPost" element={<AddPost/>}/>
        <Route path="/ProfileFeed" element={<ProfileFeed/>}/>
        <Route path="/EditP" element={<EditP/>}/>
        <Route path="LoginForm" element={<LoginForm/>}/>
        <Route path="/test" element={<Testing/>}/>
      </Routes>
    </BrowserRouter>                                 
    {/* <SearchBar/>
    <AddPost/> */}
    
    </div>
    
    

    
    
  );
}

export default App;
